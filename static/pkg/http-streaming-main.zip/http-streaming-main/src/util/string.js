export const uint8ToUtf8 = (uintArray) =>
  decodeURIComponent(escape(String.fromCharCode.apply(null, uintArray)));
