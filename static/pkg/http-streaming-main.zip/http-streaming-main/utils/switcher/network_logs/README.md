Sources from http://skuld.cs.umass.edu/traces/mmsys/2013/pathbandwidth/:
- car.snaroya-smestad.txt - http://skuld.cs.umass.edu/traces/mmsys/2013/pathbandwidth/car.snaroya-smestad/report.2011-02-14_2139CET.log
- bus.ljansbakken-oslo.txt - http://skuld.cs.umass.edu/traces/mmsys/2013/pathbandwidth/bus.ljansbakken-oslo/report.2011-01-31_1025CET.log
- train.vestby-oslo.txt - http://skuld.cs.umass.edu/traces/mmsys/2013/pathbandwidth/train.vestby-oslo/report.2011-02-14_1728CET.log
- ferry.nesoddtangen-oslo.txt - http://skuld.cs.umass.edu/traces/mmsys/2013/pathbandwidth/ferry.nesoddtangen-oslo/report.2011-02-01_1639CET.log